package App;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import Movie.MovieServiceImpl;

@Configuration
public class Cpnfig {
	 

	@Bean
	public Movie.MovieService MovieService() {
	    return new MovieServiceImpl();
	}

	}


