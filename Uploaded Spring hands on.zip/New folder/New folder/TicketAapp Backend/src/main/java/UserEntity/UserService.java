package UserEntity;

import org.springframework.stereotype.Service;

@Service
public interface  UserService {
	
public static UserEntityI saveUser(UserEntityI user) {
	// TODO Auto-generated method stub
	return null;
}
	
	public UserEntityI getUserById(Long id);

	UserEntityI saveUser1(UserEntityI user);

	UserEntityI getUserById1(Long id);

}
