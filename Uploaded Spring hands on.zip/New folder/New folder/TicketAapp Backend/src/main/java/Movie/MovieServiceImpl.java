package Movie;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Transactional
@Component
@Repository
@Service

public  class MovieServiceImpl implements MovieService {
	@Autowired
	private MovieRepository movieRepository;
	@Override
	public MovieI saveMovie1(MovieI movie) {
		return movieRepository.save(movie);
	}
	@Override
	public List<MovieI> fetchAllMovies() {
		return movieRepository.findAll();
	}
	@Override
	public MovieI fetchMovieById(Long id) {
		MovieI m =  movieRepository.findById(id).orElseThrow();
		System.out.println(m);
		return m;
	}
	@Override
	public List<MovieI> fetchMovieInInox1() {
		return movieRepository.fetchByType("INOX");
	}
	@Override
	public List<MovieI> fetchMovieInPvr() {
		return movieRepository.fetchByType("PVR");
	}
	
	@Override
	public Long getScreenId(Long id) {
		return movieRepository.getScreenId(id);
	}
	public MovieI saveMovie(MovieI movie) {
		// TODO Auto-generated method stub
		return null;
	}
	@Override
	public List<MovieI> fetchMovieInInox() {
		// TODO Auto-generated method stub
		return null;
	}
	
	
	
		}


