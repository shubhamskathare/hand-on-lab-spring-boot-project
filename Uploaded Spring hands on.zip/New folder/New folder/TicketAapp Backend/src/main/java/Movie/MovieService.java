package Movie;

import java.util.List;

import org.springframework.stereotype.Service;


@Service
public interface MovieService {
public static MovieI saveMovie(MovieI movie) {
	// TODO Auto-generated method stub
	return null;
}
	
	public List<MovieI> fetchAllMovies();
	
	public MovieI fetchMovieById(Long id);
	
	public List<MovieI> fetchMovieInInox();
	
	public List<MovieI> fetchMovieInPvr();
		
	public Long getScreenId(Long id);



	MovieI saveMovie1(MovieI movie);

	List<MovieI> fetchMovieInInox1();

}
