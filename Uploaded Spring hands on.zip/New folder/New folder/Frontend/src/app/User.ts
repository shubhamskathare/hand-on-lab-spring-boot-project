export class User{
    id!:BigInteger;
    age!:BigInteger;
    firstName!:String;
    lastName!:String;
    mail!:String;
    password!:String;
}