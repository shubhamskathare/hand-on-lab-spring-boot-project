package Screen;



import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;



@Service

@Transactional
public class ScreenServiceImpl implements ScreenService {
	
	@Autowired
	private ScreenRepository screenRepository;
	@Override
	public ScreenI saveScreen(ScreenI screen) {
		return screenRepository.save(screen);
	}
	@Override
	public List<ScreenI> fetchAllScreens() {
		return screenRepository.findAll();
	}
	@Override
	public ScreenI fetchScreenById(Long id) {
		return screenRepository.findById(id).orElseThrow();
	}
	@Override
	public List<ScreenI> fetchScreensOfInox() {
		return screenRepository.fetchByType("INOX");
	}
	@Override
	public List<ScreenI> fetchScreensOfPvr() {
		return screenRepository.fetchByType("PVR");

	}
	


}
