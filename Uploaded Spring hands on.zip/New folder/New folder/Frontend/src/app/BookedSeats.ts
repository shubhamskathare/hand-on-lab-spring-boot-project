
export class BookedSeats{
    bookingId!:number;
    movieId!:number;
    movieName!:String;
    userId!:number;
    screenName!:String;
    amount!:number;
    date!:Date;
    time!:string;
    seatType!:String;
    noOfSeats!:number;
}