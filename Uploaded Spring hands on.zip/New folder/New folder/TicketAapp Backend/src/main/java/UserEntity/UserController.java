package UserEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")
public class UserController {
	@Autowired
	UserEntityServiceImpl userService;
	
	@PostMapping("/user")
	public UserEntityI registerUser(@RequestBody UserEntityI user) {
		return userService.saveUser(user);
		
	}
	
	@GetMapping("/user/{id}")
	public UserEntityI getUser(@PathVariable Long id) {
		return userService.getUserById(id);
	}
	
	

}
