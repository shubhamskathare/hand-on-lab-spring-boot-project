export class screen{
    screenId!:number;
    name!:String;
    goldSeat!:number;
    platinumSeats!:number;
    silverSeats!:number;
    
}