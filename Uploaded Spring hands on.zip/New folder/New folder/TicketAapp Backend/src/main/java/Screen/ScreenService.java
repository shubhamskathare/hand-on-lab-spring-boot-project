package Screen;

import java.util.List;


public interface ScreenService {
public ScreenI saveScreen(ScreenI screen);
	
	public List<ScreenI> fetchAllScreens();
	
	public ScreenI fetchScreenById(Long id);
	
	public List<ScreenI> fetchScreensOfInox();

	public List<ScreenI> fetchScreensOfPvr();

	


}
