package UserEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;



@Service
@Transactional

public class UserEntityServiceImpl implements UserService {
	
	@Autowired
	private UserRepository repository;

	@Override
	public UserEntityI saveUser1(UserEntityI user) {
		return repository.save(user);
	}


	@Override
	public UserEntityI getUserById1(Long id) {
		return repository.findById(id).orElseThrow();
	}


	public UserEntityI saveUser(UserEntityI user) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public UserEntityI getUserById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}
	

}
