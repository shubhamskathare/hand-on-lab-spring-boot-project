package Movie;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
@CrossOrigin(origins = "*")

public class MovieController {
	
	@Autowired
	private MovieServiceImpl movieService;

	@PostMapping("movie")
	public MovieI saveMovieI(@RequestBody MovieI movie) {
		return movieService.saveMovie(movie);
	}
	
	@GetMapping("allmovies")
	public List<MovieI> fetchAllMovies(){
		return movieService.fetchAllMovies();
	}
	
	@GetMapping("movie/{id}")
	public MovieI fetchById(@PathVariable Long id) {
		return movieService.fetchMovieById(id);
	}
	
	@GetMapping("movie/INOX")
	public List<MovieI> fetchByInox(){
		return movieService.fetchMovieInInox();
	}
	@GetMapping("movie/PVR")
	public List<MovieI> fetchByPvr(){
		return movieService.fetchMovieInPvr();
	}
	
	
	@GetMapping("movscr/{id}")
	public Long getScreenId(@PathVariable Long id) {
		return movieService.getScreenId(id);
	}

}
