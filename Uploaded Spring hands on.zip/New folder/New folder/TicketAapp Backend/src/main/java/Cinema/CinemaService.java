package Cinema;



public interface CinemaService {
	public static CinemaIF saveCinema(CinemaIF cinema) {
		// TODO Auto-generated method stub
		return null;
	}

}
