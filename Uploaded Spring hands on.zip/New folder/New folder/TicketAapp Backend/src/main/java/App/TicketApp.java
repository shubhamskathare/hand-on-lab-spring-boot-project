package App;


import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.filter.CommonsRequestLoggingFilter;

import Cinema.CinemaIF;
import Cinema.CinemaService;
import Cinema.CinemaServiceImpl;
import Movie.MovieI;
import Movie.MovieService;
import Movie.MovieServiceImpl;
import Screen.ScreenI;
import UserEntity.UserEntityI;
import UserEntity.UserEntityServiceImpl;
import UserEntity.UserService; 



@SpringBootApplication
@ComponentScan(basePackages = {"/TicketAapp/src/main/java/Movie/MovieController.java"})

public class TicketApp  implements CommandLineRunner {

	public static void main(String[] args) {
		SpringApplication.run(TicketApp.class, args);
	}
	

	//Log information about the exception

	@Bean
	public CommonsRequestLoggingFilter requestLoggingFilter() {
	CommonsRequestLoggingFilter loggingFilter = new CommonsRequestLoggingFilter();
	loggingFilter.setIncludeClientInfo(true);
	loggingFilter.setIncludeQueryString(true);
	loggingFilter.setIncludePayload(true);
	loggingFilter.setMaxPayloadLength(64000);
	return loggingFilter;
	}


	//Add admin data to database
	public void run(MovieService movieService, String... args) throws Exception {
	// TODO Auto-generated method snippet
	UserEntityI user1 = new UserEntityI("abi@gmail.com","ravi@2000","ali","ram",25);
	UserService.saveUser(user1);
	ScreenI s1 = new ScreenI("Screen1",100,140,160,"3D");
	ScreenI s2 = new ScreenI("Screen2",145,160,225,"2D");
	MovieI m1 = new MovieI("pushpa",LocalDate.of(2016, 7, 21),4,4,"Telugu","U/A");
	m1.setScreenI(s1);
	MovieI m2 = new MovieI("black",LocalDate.of(2020, 6, 16),4,4.5,"English","U");
	m2.setScreenI(s2);
	MovieService.saveMovie(m1);
	MovieService.saveMovie(m2);

	List<ScreenI> li = new ArrayList<>();
	li.add(s1);
	li.add(s2);

	CinemaIF c1 = newCinemaIF ("Hyderabad","jntu","PVR");
	CinemaIF.saveCinema(c1);
	c1.setScreens(li);
	CinemaIF.saveCinema(c1);

	ScreenI s3 = new ScreenI("Screen_A",110,150,220,"3D");
	ScreenI s4 = new ScreenI("Screen_B",100,160,180,"2D");
	ScreenI s5 = new ScreenI("Screen_C",120,160,1950,"3D");
	MovieI m3 = new MovieI("T1",LocalDate.of(2019, 9, 25),4,4.25,"Telugu","U/A");
	m3.setScreenI(s3);
	MovieI m4 = new MovieI("T2",LocalDate.of(2022, 2, 16),4,4.5,"Telugu","U");
	m4.setScreenI(s4);
	MovieI m5 = new MovieI("T3 ",LocalDate.of(2022, 6, 15),4,4.7,"Hindi","U");
	m5.setScreenI(s5);
	MovieService.saveMovie(m3);
	MovieService.saveMovie(m4);
	MovieService.saveMovie(m5);

	List<ScreenI> li1 = new ArrayList<>();
	li1.add(s3);
	li1.add(s4);
	li1.add(s5);

	CinemaIF c2 = newCinemaIF("Kamala","SeetaramaPuram jpt","INOX");
	CinemaService.saveCinema(c2);
	c2.setScreens(li1);
	CinemaService.saveCinema(c2);
	}


	private CinemaIF newCinemaIF(String string, String string2, String string3) {
		// TODO Auto-generated method stub
		return null;
	}


	@Override
	public void run(String... args) throws Exception {
		// TODO Auto-generated method stub
		
	}


}
