package Screen;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


@RestController
@CrossOrigin(origins = "*")
public class ScreenController {
	
	@Autowired
	private ScreenServiceImpl serviceImpl;
	
	@PostMapping("/screen")
	public ScreenI saveScreen(@RequestBody ScreenI screen) {
		return serviceImpl.saveScreen(screen);
	}
	
	@GetMapping("/allscreens")
	public List<ScreenI> fetchAllScreens(){
		return serviceImpl.fetchAllScreens();
	}
	
	@GetMapping("/screen/{id}")
	public ScreenI fetchById(@PathVariable Long id ) {
		return serviceImpl.fetchScreenById(id);
	}
	@GetMapping("/screen/INOX")
	public List<ScreenI> getScreensOfInox(){
		return serviceImpl.fetchScreensOfInox();
	}
	@GetMapping("/screen/PVR")
	public List<ScreenI> getScreensOfPvr(){
		return serviceImpl.fetchScreensOfPvr();
	}

}
